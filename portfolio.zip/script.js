function toggleMenu() {
  const menu = document.querySelector(".menu-links");
  const icon = document.querySelector(".hamburger-icon");
  menu.classList.toggle("open");
  // icon.classList.toggle("open");
}

function toggleDarkMode() {
  const body = document.body;
  body.classList.toggle("dark-mode");
  const isDarkMode = body.classList.contains("dark-mode");
  localStorage.setItem("dark-mode", isDarkMode);
}

// Check for user's preference on page load
document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const savedDarkMode = localStorage.getItem("dark-mode") === "true";
  if (savedDarkMode) {
    body.classList.add("dark-mode");
  }
});

document.getElementById("btn1").onclick = function () {
  var url = "https://github.com/neeraj4936/B-FITNESS";
  window.open(url, "_blank");
};

document.getElementById("btn2").onclick = function () {
  var url = "https://github.com/neeraj4936/B-FITNESS";
  window.open(url, "_blank");
};

document.getElementById("btn3").onclick = function () {
  var url = "https://github.com/neeraj4936/Virat-Kohli-Blog";
  window.open(url, "_blank");
};

document.getElementById("btn4").onclick = function () {
  var url = "https://github.com/neeraj4936/Virat-Kohli-Blog";
  window.open(url, "_blank");
};

document.getElementById("btn5").onclick = function () {
  var url = "https://github.com/neeraj4936/NIKE-Website.github.io";
  window.open(url, "_blank");
};

document.getElementById("btn6").onclick = function () {
  var url = "https://github.com/neeraj4936/NIKE-Website.github.io";
  window.open(url, "_blank");
};
